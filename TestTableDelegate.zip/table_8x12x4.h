﻿#ifndef TABLE_8X12X4_H
#define TABLE_8X12X4_H

#include <qboxlayout.h>
#include "tablewidgetbase.h"


class Table_8x12x4 : public QWidget
{
    Q_OBJECT
public:
    explicit Table_8x12x4(QWidget *parent = nullptr);

signals:

};

#endif // TABLE_8X12X4_H
