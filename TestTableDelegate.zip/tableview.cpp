﻿#include "tableview.h"

TableView::TableView(QWidget*parent):QTableView(parent)
{


}
